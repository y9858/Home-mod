# LuCI client side API documentation

You can browse the JavaScript apis provided by LuCI here. A good starting point
is the central [luci.js class](https://openwrt.github.io/luci/jsapi/LuCI.html).

