'use strict';
'require tools.views as views';

return views.LogreadBox("acme", _('ACME Log'));