'use strict';
'require tools.views as views';

return views.LogreadBox("adblock-", _('Adblock Log'));