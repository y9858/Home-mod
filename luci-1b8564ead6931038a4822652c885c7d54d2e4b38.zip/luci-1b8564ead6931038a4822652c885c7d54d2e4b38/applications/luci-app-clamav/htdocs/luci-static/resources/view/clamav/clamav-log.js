'use strict';
'require tools.views as views';

return views.LogreadBox("clamav", _('ClamAV Log'));
