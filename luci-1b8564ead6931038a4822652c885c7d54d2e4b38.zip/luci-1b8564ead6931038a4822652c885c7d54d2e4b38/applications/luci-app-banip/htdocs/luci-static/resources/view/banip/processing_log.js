'use strict';
'require tools.views as views';

return views.LogreadBox("banIP-", _('banIP Log'));
